import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServicesService } from '../auth-services.service';
import { Registerresponsemodel } from '../authresponsemodels/registerresponsemodel';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  constructor(
    private router:Router,
    private registerservice:AuthServicesService,
    private formBuilder:FormBuilder
  ) { }

  registerForm:FormGroup;
  registerResponse:Registerresponsemodel[];
  GenderArray=["Male","Female"];
  countries=[{"CountryID":1,"CountryName":"INDIA"},
  {"CountryID":2,"CountryName":"PAKISTAN"},
  {"CountryID":3,"CountryName":"SAUDI ARABIA"}
  ]


  
  ngOnInit() {
 
    this.registerForm = this.formBuilder.group({
      username:[null,Validators.required],
      password: [null,Validators.required],
      email:[null,[Validators.required,Validators.email]],
      mobilenumber:[null,[Validators.required,Validators.maxLength(12),Validators.minLength(12),Validators.pattern("^((\\+91-?)|0)?[0-9]{12}$")]],
      gender: [null,Validators.required],
      dob:[null,Validators.required],
      countryddl:[null,Validators.required]
   
   });
   console.log(this.registerForm)
  }

  Login()
  {
    this.router.navigate(['login']);
  }
  Register()
  {

    
    debugger;
    console.log(this.registerForm)

    if(this.registerForm.valid)
    {
    this.registerservice.Register(this.registerForm.value).subscribe((response:Registerresponsemodel[])=>{
      this.registerResponse=response
      console.log(this.registerResponse);
    },(error)=>{
      console.log(error);
    })
  }
  }
}
