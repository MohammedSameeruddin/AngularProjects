import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServicesService } from '../auth-services.service';
import { Signinmodel } from '../authmodels/signinmodel';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

import { Signinresponse } from '../authresponsemodels/signinresponse';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(
    private route:Router,
    private signInService:AuthServicesService,
    private formBuilder:FormBuilder

  ) { }
  
  SignInRequest:FormGroup;
  //loginrequest:Signinmodel[];
  people:Signinmodel[];
  loginrequest = new Signinmodel();

 
  //loginform=new Signinmodel();

token:string=null;
  ngOnInit() {
    this.SignInRequest=this.formBuilder.group({
username:["",[Validators.required]],
password:["",[Validators.required]]

    })
  }

  // tempLogin(loginform)
  // {
  //   debugger;
  //   console.log(loginform.value)
  // }

  AuthLogin(SignInRequest)
  {
   // console.log(this.loginform)
    debugger;
    if(SignInRequest.valid)
    {
    this.signInService.SignIn(SignInRequest.value).subscribe((response:Signinresponse)=>{
      this.token=response.auth_token;
      this.route.navigate(['dashboard']);
    console.log(this.token);
  
    },(error)=>{console.log(error)})};
   
  }

  Register()
  {
    this.route.navigate(['Register']);
  }
  ForgotPassword()
  {
    this.route.navigate(['Forgot']);
  }

}
