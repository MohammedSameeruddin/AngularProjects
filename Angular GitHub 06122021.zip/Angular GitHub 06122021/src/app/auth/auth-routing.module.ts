import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AuthComponent } from './auth.component';
import { RegisterComponent } from './register/register.component';
import { Page404Component } from './page404/page404.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { Page401Component } from './page401/page401.component';
import { CanActivateGuardService } from '../guards/can-activate-guard.service';


const routes: Routes = [
  {path:'',component:AuthComponent,
  children:[
    {path:'',component:LoginComponent},
    {path:'login',component:LoginComponent},
    {path:'Register',component:RegisterComponent},
    {path:'Forgot',component:ForgotPasswordComponent},
   { path:'notFound',component:Page404Component},
   { path:'unauthorized',component:Page401Component}
  
  ]  
},
{
  path:'dashboard', loadChildren:() => import('../layout/layout.module').then(m =>m.LayoutModule),canActivate:[CanActivateGuardService],

},
// {
//   path:'Patient', loadChildren:() => import('../patients/patients.module').then(m =>m.PatientsModule)
// },
// {
//   path:'Doctor', loadChildren:() => import('../doctor/doctor.module').then(m =>m.DoctorModule)
// }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
