import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';

import { AuthComponent } from './auth.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { LockScreenComponent } from './lock-screen/lock-screen.component';
import { Page404Component } from './page404/page404.component';
import { Page505Component } from './page505/page505.component';
import { ProfileComponent } from './profile/profile.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthServicesService } from './auth-services.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { JwtinterceptorService } from '../interceptor/jwtinterceptor.service';
import { JwtunauthorizedinterceptorService } from '../interceptor/jwtunauthorizedinterceptor.service';
import { Page401Component } from './page401/page401.component';
import { JwtModule } from '@auth0/angular-jwt';
import { NgxSpinnerModule } from 'ngx-spinner';



@NgModule({
  declarations: [AuthComponent, LoginComponent, RegisterComponent, ForgotPasswordComponent, LockScreenComponent, Page404Component, Page505Component, ProfileComponent, Page401Component],
  imports: [
    SharedModule,
    AuthRoutingModule,
   FormsModule,
   
  ReactiveFormsModule,
HttpClientModule,
CommonModule,
NgxSpinnerModule
// JwtModule.forRoot({
//   config:{
//     tokenGetter:()=>{
//       return localStorage.getItem("user")?JSON.parse(localStorage.getItem("user")):null}
//   }
// })
  ],
  providers:[AuthServicesService,
  {provide:HTTP_INTERCEPTORS,
  useClass:JwtinterceptorService,
multi:true},{provide:HTTP_INTERCEPTORS,
useClass:JwtunauthorizedinterceptorService,
multi:true}]
})
export class AuthModule { }
