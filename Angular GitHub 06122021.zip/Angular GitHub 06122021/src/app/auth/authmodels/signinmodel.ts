export class Signinmodel {
    UserName:string;
    Password:string;
}
