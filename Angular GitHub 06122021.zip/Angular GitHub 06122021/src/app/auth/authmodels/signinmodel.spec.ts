import { Signinmodel } from './signinmodel';

describe('Signinmodel', () => {
  it('should create an instance', () => {
    expect(new Signinmodel()).toBeTruthy();
  });
});
