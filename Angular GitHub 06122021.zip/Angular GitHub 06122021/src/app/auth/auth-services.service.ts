import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Signinmodel } from './authmodels/signinmodel';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Signinresponse } from './authresponsemodels/signinresponse';
import { Registermodel } from './models/registermodel';


@Injectable({
  providedIn: 'root'
})
export class AuthServicesService {

  constructor(private httpclient: HttpClient,private jwtHelper:JwtHelperService
   ) { }

    // ServiceUrl:string="https://localhost:44387/";
  ServiceUrl:string="http://sameeruddin-001-site1.itempurl.com/";
   auth_token:string=null;
   username:string=null;

   signInResponse:Signinresponse[];
  SignIn(signinmodels:Signinmodel):Observable<any>
  {
    debugger;
    return this.httpclient.post<any>(this.ServiceUrl+"api/Account/SignIn",signinmodels,{responseType:"json"}).pipe(map(user=>{
     if(user)
     {
         this.signInResponse=user;
         //this.username=user.username;
         localStorage.setItem('user',JSON.stringify(this.signInResponse));
     }
     return user;
     }))
  }

  Register(register:Registermodel):Observable<any>
  {
    return this.httpclient.post<any>("https://localhost:44387/api/Account/UserRegistration",register,{responseType:"json"});
  }

  IsAuthenticate():boolean
  {
    debugger;
      
    //var authToken=JSON.parse(localStorage.getItem("user")).auth_token;
   var token= localStorage.getItem("user")?JSON.parse(localStorage.getItem("user")).auth_token:null
   if(this.jwtHelper.isTokenExpired())
   {
     return false
  }else{
    return true
  }

  }
  
}
