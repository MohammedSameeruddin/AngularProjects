

export class Registermodel {

        id:number;
        userName: string;
        password: string;
        emailAddress: string;
        mobileNumber: string;
        gender: string;
        dateOfBirth:string;
        createdBy: number;
        createdOn: string;
        editedBy: number;
        editedOn: string
        status: number;
        isActive: boolean;
   
}
