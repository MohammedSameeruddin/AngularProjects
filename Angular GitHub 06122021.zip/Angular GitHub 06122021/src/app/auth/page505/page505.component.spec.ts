import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { Page505Component } from './page505.component';

describe('Page505Component', () => {
  let component: Page505Component;
  let fixture: ComponentFixture<Page505Component>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ Page505Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Page505Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
