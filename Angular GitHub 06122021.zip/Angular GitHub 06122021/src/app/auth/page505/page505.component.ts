import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page505',
  templateUrl: './page505.component.html',
  styleUrls: ['./page505.component.scss']
})
export class Page505Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
