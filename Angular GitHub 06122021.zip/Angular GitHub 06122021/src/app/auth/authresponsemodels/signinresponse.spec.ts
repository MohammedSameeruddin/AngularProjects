import { Signinresponse } from './signinresponse';

describe('Signinresponse', () => {
  it('should create an instance', () => {
    expect(new Signinresponse()).toBeTruthy();
  });
});
