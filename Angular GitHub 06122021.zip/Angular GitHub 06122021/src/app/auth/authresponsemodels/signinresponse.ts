export class Signinresponse {
    auth_token:string;
    username:string;

}
