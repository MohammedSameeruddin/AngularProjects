import { Registerresponsemodel } from './registerresponsemodel';

describe('Registerresponsemodel', () => {
  it('should create an instance', () => {
    expect(new Registerresponsemodel()).toBeTruthy();
  });
});
