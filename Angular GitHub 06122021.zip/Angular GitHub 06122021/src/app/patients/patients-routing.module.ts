import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientsComponent } from './patients.component';
import { AddComponent } from './add/add.component';
import { DashboardComponent } from '../layout/dashboard/dashboard.component';
import { PatientListComponent } from './patient-list/patient-list.component';


const routes: Routes = [
  {path:'',component:PatientsComponent,
  children:[
    {path:'',component:PatientsComponent},
    {path:'Add',component:AddComponent},
    {path:'List',component:PatientListComponent},
    
  ]  
},
  // {path:'', component:PatientsComponent,
  //  children:[
  //    { path:'Add',component:AddComponent}
  //  ]
  // },
//   { path:'',component:PatientsComponent
    

// },
//    { path:'Add',component:AddComponent},
//    { path:'patientList',component:PatientsComponent},
   
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientsRoutingModule { }
