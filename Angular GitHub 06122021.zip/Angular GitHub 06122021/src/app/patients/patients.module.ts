import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PatientsRoutingModule } from './patients-routing.module';
import { PatientsComponent } from './patients.component';
import { AddComponent } from './add/add.component';
import { DashboardComponent } from '../layout/dashboard/dashboard.component';
import { PatientListComponent } from './patient-list/patient-list.component';



@NgModule({
  declarations: [PatientsComponent, AddComponent, PatientListComponent],
  imports: [
    CommonModule,
    PatientsRoutingModule
  ],
  exports:[
    PatientsComponent,
    AddComponent
  ]
})
export class PatientsModule { }
