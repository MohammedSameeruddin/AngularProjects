import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthServicesService } from '../auth/auth-services.service';

@Injectable({
  providedIn: 'root'
})
export class CanActivateGuardService implements CanActivate {

  constructor(private loginService:AuthServicesService,private router:Router) { }

  canActivate():boolean
  {
    debugger;
    if(this.loginService.IsAuthenticate())
    {
      return true
    }
    else
    {
      this.router.navigate(["login"]);
      return false
    }
  }
}
