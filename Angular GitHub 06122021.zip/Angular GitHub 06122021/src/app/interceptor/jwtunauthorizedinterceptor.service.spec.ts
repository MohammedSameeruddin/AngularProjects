import { TestBed } from '@angular/core/testing';

import { JwtunauthorizedinterceptorService } from './jwtunauthorizedinterceptor.service';

describe('JwtunauthorizedinterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: JwtunauthorizedinterceptorService = TestBed.get(JwtunauthorizedinterceptorService);
    expect(service).toBeTruthy();
  });
});
