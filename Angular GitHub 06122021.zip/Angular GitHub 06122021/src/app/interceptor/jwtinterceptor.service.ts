import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JwtinterceptorService implements HttpInterceptor {

  constructor(private SpinnerService:NgxSpinnerService) { }

  intercept(request:HttpRequest<any>,next:HttpHandler):Observable<HttpEvent<any>>
  {
    this.SpinnerService.show(); 
    debugger
    var currentuser={token:""}
    if(localStorage.user!=null)
    {
      currentuser=JSON.parse(localStorage.user).auth_token;
    }
   request= request.clone({
     setHeaders:{
       Authorization:'Bearer '+ currentuser 
     }
    // headers:request.headers.set("Authorization","Bearer"+currentuser)
     
    })
    this.SpinnerService.hide(); 
    console.log(request);
    return next.handle(request);
  }
}
