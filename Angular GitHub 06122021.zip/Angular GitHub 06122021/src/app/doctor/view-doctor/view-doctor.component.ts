import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from '../services/doctor.service';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.scss']
})
export class ViewDoctorComponent implements OnInit {

  constructor(private route:ActivatedRoute,private doctorService:DoctorService ) { }
  doctorObject:any;
  ngOnInit() {
debugger;
    let doctorid =  JSON.parse(this.route.snapshot.params.doctorid);
    console.log(doctorid);
 this.getDoctorByID(doctorid)
  }

  getDoctorByID(doctorid:number)
  {
    debugger;
    //this.SpinnerService.show();  
    this.doctorService.getDoctorByID(doctorid).subscribe((response:any)=>{
     
this.doctorObject=response
//this.SpinnerService.hide(); 
    }
    ,(error)=>{console.log(error)})
  }

}
