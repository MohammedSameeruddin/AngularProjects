import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { DoctorService } from '../services/doctor.service';

@Component({
  selector: 'app-add-doctor',
  templateUrl: './add-doctor.component.html',
  styleUrls: ['./add-doctor.component.scss']
})
export class AddDoctorComponent implements OnInit {

  doctorForm:FormGroup;
  constructor(private formBuilder:FormBuilder,private doctorService:DoctorService) { }
  SavedDoctor:any;
  ngOnInit() {
    this.doctorForm=this.formBuilder.group({
      firstName:["",[Validators.required]],
      middleName:["",[Validators.required]],
      lastName:["",[Validators.required]],
      email:["",[Validators.required,Validators.email]],
      mobileNumber:["",[Validators.required,Validators.minLength(12),Validators.pattern("^((\\+91-?)|0)?[0-9]{12}$")]],
      doctorID:[0],
      isActive:[true]
     })
  }

  SaveDoctorProfile()
  {
    debugger;
    console.log(this.doctorForm);
    if(this.doctorForm.valid)
    {
    
this.doctorService.SaveDoctorInfo(this.doctorForm.value).subscribe(
  (saveResponse:any)=>{
    this.SavedDoctor=saveResponse
    // this.messageService.add({severity:'success',  summary:'Record added successfully'});
  },

(error)=>{console.log(error)})

    }

  }

}
