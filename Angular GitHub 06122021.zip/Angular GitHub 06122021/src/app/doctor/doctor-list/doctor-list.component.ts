import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { DoctorResponseModel } from '../models/doctor-response-model';
import { DoctorService } from '../services/doctor.service';

import { PagingModel } from '../models/paging-model';


@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.scss']
})
export class DoctorListComponent implements OnInit {

  constructor(private doctorService:DoctorService,
    private route:Router,private SpinnerService: NgxSpinnerService) { }
   Doctors:DoctorResponseModel[];
   newdoctors=new DoctorResponseModel();
   editDoctors =new DoctorResponseModel();
   totalCounts:string;
   rowsPerPage:string;
   paramValues=new PagingModel();
   disablePrevious:boolean=true;
   disableNext:boolean=false;
  ngOnInit() {
    this.paramValues.pageIndex=1;
    this.paramValues.pageSize=15;
this.rowsPerPage="10";

debugger;
this.GetAllDoctors(this.paramValues);
  }

  getNextPage()
  {
    debugger;

   this.paramValues.pageIndex=this.paramValues.pageIndex+1;
   if(this.paramValues.pageIndex>1 )
   {
    if(this.Doctors.length<=5)
{
 this.disableNext=true;
//  this.disablePrevious=true;
}
   //  this.disableNext=false;
     this.disablePrevious=false;
   }
  //  else
  //  {
  //    this.disableNext=false;
  //    this.disablePrevious=false;
  //  }
   this.GetAllDoctors(this.paramValues);

  }

  getPreviousPage()
  {
    debugger;
    this.paramValues.pageIndex=this.paramValues.pageIndex-1;
   
    if(this.paramValues.pageIndex==1)
    {
      this.disablePrevious=true;
      this.disableNext=false;

    }
    // else
    // {
    //   this.disablePrevious=false;

    // }
    this.GetAllDoctors(this.paramValues);
  }

  GetAllDoctors(paramPaging:PagingModel)
  {

    this.SpinnerService.show();

  this.doctorService.getDoctors(paramPaging).subscribe((GetAllDoctors:DoctorResponseModel[])=>{
  this.Doctors=GetAllDoctors;
  this.totalCounts=JSON.stringify(GetAllDoctors.length);
  console.log(JSON.stringify(GetAllDoctors.length));
this.rowsPerPage="10";
  console.log(this.Doctors)
  this.SpinnerService.hide();
  },
  (error)=>{
    console.log(error)
  }

  )



  }

//   editdoctor($event,index:number)
//   {
// debugger;
//     this.editDoctors.firstName=this.Doctors[index].firstName;
//     this.editDoctors.middleName=this.Doctors[index].middleName;
//     this.editDoctors.lastName=this.Doctors[index].lastName;
//     this.editDoctors.mobileNumber=this.Doctors[index].mobileNumber;
//     this.editDoctors.email=this.Doctors[index].email;

//     // this.route.navigate(['Doctors/editdoctor/',this.Doctors.doctorid]);

//   }

}
