import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DoctorRoutingModule } from './doctor-routing.module';

import { AddDoctorComponent } from './add-doctor/add-doctor.component';
import { DoctorComponent } from './doctor.component';

import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { EditdoctorComponent } from './editdoctor/editdoctor.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ViewDoctorComponent } from './view-doctor/view-doctor.component';
import {ToastModule} from 'primeng/toast';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MessageService } from 'primeng/api';
import {PaginatorModule} from 'primeng/paginator';










@NgModule({
  declarations: [DoctorComponent, AddDoctorComponent, DoctorListComponent, DoctorHomeComponent, EditdoctorComponent, ViewDoctorComponent],
  imports: [
    DoctorRoutingModule,
  CommonModule,
  FormsModule,
  NgxSpinnerModule,

  ReactiveFormsModule,
  ToastModule,
  PaginatorModule
  



  

  ],
  providers:[MessageService],
  exports:[
    DoctorComponent,AddDoctorComponent
  ]
})
export class DoctorModule { }
