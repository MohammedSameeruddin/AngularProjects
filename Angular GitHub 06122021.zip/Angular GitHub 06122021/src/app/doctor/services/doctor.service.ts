import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DoctorListModel } from '../models/doctor-list-model';

import { DoctorResponseModel } from '../models/doctor-response-model';
import { PagingModel } from '../models/paging-model';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {

 // ServiceUrl:string="https://localhost:44387/";
  ServiceUrl:string="http://sameeruddin-001-site1.itempurl.com/";

  constructor(private httpclient:HttpClient) { }

  getDoctors(pagingdata:PagingModel):Observable<any>
  {
  return  this.httpclient.get<any>(this.ServiceUrl+"api/Doctors/GetAllDoctors?pageIndex="+pagingdata.pageIndex+"&pageSize="+pagingdata.pageSize);
  }

  getDoctorByID(doctorID:number):Observable<any>
  {
    debugger;
  return  this.httpclient.get<any>(this.ServiceUrl+"api/Doctors/GetDoctorByID?doctorID="+doctorID);
  }

  Updatedoctor(updatedoctorrequest:any):Observable<any>
  {
    debugger;
  return  this.httpclient.post<any>(this.ServiceUrl+"api/Doctors/UpdateDoctors",updatedoctorrequest);
  
  }

  SaveDoctorInfo(doctorinfo:any):Observable<any>
  {
return this.httpclient.post<any>(this.ServiceUrl+"api/Doctors/PostDoctors",doctorinfo)
  }

  getDoctorCounts():Observable<any>
  {
    return this.httpclient.get<any>(this.ServiceUrl+"api/Doctors/GetDoctorsCount");
  }
  
}
