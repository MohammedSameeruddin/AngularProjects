import { DoctorResponseModel } from './doctor-response-model';

describe('DoctorResponseModel', () => {
  it('should create an instance', () => {
    expect(new DoctorResponseModel()).toBeTruthy();
  });
});
