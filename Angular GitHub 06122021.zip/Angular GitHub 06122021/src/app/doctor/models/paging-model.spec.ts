import { PagingModel } from './paging-model';

describe('PagingModel', () => {
  it('should create an instance', () => {
    expect(new PagingModel()).toBeTruthy();
  });
});
