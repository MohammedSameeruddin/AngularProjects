export class PagingModel {
    pageIndex:number;
    pageSize:number;


    
    
}
