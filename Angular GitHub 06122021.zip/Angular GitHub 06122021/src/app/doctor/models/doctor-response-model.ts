export class DoctorResponseModel {

    doctorid:number;
    firstName:string;
    middleName:string;
    lastName:string;
    email:string;
    mobileNumber:string;
    createdBy:number;
    createdOn:string;
    editedBy:number;
    editedOn:string;
    isActive:boolean;

}
