import { DoctorListModel } from './doctor-list-model';

describe('DoctorListModel', () => {
  it('should create an instance', () => {
    expect(new DoctorListModel()).toBeTruthy();
  });
});
