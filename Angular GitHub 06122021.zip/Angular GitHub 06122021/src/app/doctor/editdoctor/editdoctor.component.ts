import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DoctorListModel } from '../models/doctor-list-model';
import { DoctorResponseModel } from '../models/doctor-response-model';
import { DoctorService } from '../services/doctor.service';
import {MessageService} from 'primeng/api';


@Component({
  selector: 'app-editdoctor',
  templateUrl: './editdoctor.component.html',
  styleUrls: ['./editdoctor.component.scss']
})
export class EditdoctorComponent implements OnInit {

  constructor(private route:ActivatedRoute,private doctorService:DoctorService,private SpinnerService:NgxSpinnerService,public messageService:MessageService) { }

doctorByID:any;
updateRequest=new DoctorListModel();
updateDoctor:DoctorListModel[];

  ngOnInit() {
    debugger;
    let doctorid =  JSON.parse(this.route.snapshot.params.doctorid);
      console.log(doctorid);
   this.getDoctorByID(doctorid)

  }

  getDoctorByID(doctorid:number)
  {
    debugger;
    //this.SpinnerService.show();  
    this.doctorService.getDoctorByID(doctorid).subscribe((response:any)=>{
     
this.doctorByID=response
//this.SpinnerService.hide(); 
    }
    ,(error)=>{console.log(error)})
  }

  paginate(event) {
    //event.first = Index of the first record
    //event.rows = Number of rows to display in new page
    //event.page = Index of the new page
    //event.pageCount = Total number of pages
}


  UpdateDoctor()
  {
    this.SpinnerService.show();  
   debugger;
this.doctorService.Updatedoctor(this.doctorByID).subscribe((updatedResponse:any)=>{

  this.updateDoctor=updatedResponse;

 
  this.getDoctorByID(JSON.parse(this.route.snapshot.params.doctorid))
   this.SpinnerService.hide(); 
   
    // this.messageService.add({severity:'error',  summary:'Record updated successfully'});
    this.messageService.add({severity:'success', summary:'Record updated successfully'});
},(error)=>{
  console.log(error);
  this.SpinnerService.hide(); 
})
  }

 

}
