import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DoctorComponent } from './doctor.component';
import { AddDoctorComponent } from './add-doctor/add-doctor.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { CanActivateGuardService } from '../guards/can-activate-guard.service';
import { EditdoctorComponent } from './editdoctor/editdoctor.component';
import { ViewDoctorComponent } from './view-doctor/view-doctor.component';


const routes: Routes = [
  {path:'',component:DoctorComponent,
  children:[
    {path:'',component:DoctorComponent},
    {path:'AddDoctor',component:AddDoctorComponent,canActivate:[CanActivateGuardService]},
    {path:'List',component:DoctorListComponent,canActivate:[CanActivateGuardService]},
    {path:'editdoctor/:doctorid',component:EditdoctorComponent,canActivate:[CanActivateGuardService]},
    {path:'ViewDoctor/:doctorid',component:ViewDoctorComponent,canActivate:[CanActivateGuardService]},
    
    
  ]  
},
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctorRoutingModule { }
