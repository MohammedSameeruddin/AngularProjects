import { Component, OnInit } from '@angular/core';
import { DoctorService } from 'src/app/doctor/services/doctor.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private doctorService:DoctorService) { }
DoctorCounts:number;
  ngOnInit() {
    this.getDoctorCounts();
  }

  getDoctorCounts()
  {
this.doctorService.getDoctorCounts().subscribe(
  (responseDoctorCounts:any)=>{
    this.DoctorCounts= responseDoctorCounts.totalDoctorCounts;
  },
(error)=>{console.log(error)})
  }

}
