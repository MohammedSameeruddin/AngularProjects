import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';


const routes: Routes = [
{ path:'',component:LayoutComponent,
  children:[
    {path:'',component:DashboardComponent},
   
    {path:'patient', loadChildren: () => import('../patients/patients.module').then(m => m.PatientsModule)},
    {path:'Doctors', loadChildren: () => import('../doctor/doctor.module').then(m => m.DoctorModule)},
    {path:'Clinics', loadChildren: () => import('../clinics/clinics.module').then(m => m.ClinicsModule)}
  ]
},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
