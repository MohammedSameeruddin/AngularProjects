import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clinic-list',
  templateUrl: './clinic-list.component.html',
  styleUrls: ['./clinic-list.component.scss']
})
export class ClinicListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
