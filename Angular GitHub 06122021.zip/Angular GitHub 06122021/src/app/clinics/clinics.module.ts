import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClinicsRoutingModule } from './clinics-routing.module';
import { ClinicsComponent } from './clinics.component';
import { AddClinicsComponent } from './add-clinics/add-clinics.component';
import { ClinicListComponent } from './clinic-list/clinic-list.component';
import { ClinicHomeComponent } from './clinic-home/clinic-home.component';



@NgModule({
  declarations: [ClinicsComponent, AddClinicsComponent, ClinicListComponent, ClinicHomeComponent],
  imports: [
    CommonModule,
    ClinicsRoutingModule
  ]
})
export class ClinicsModule { }
