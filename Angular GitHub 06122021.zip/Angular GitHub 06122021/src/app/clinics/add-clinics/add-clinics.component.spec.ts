import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AddClinicsComponent } from './add-clinics.component';

describe('AddClinicsComponent', () => {
  let component: AddClinicsComponent;
  let fixture: ComponentFixture<AddClinicsComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AddClinicsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddClinicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
