import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-clinics',
  templateUrl: './add-clinics.component.html',
  styleUrls: ['./add-clinics.component.scss']
})
export class AddClinicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
