import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClinicsComponent } from './clinics.component';
import { AddClinicsComponent } from './add-clinics/add-clinics.component';
import { ClinicListComponent } from './clinic-list/clinic-list.component';
import { ClinicHomeComponent } from './clinic-home/clinic-home.component';


const routes: Routes = [
  {path:'',component:ClinicsComponent,
  children:[
    {path:'',component:ClinicHomeComponent},
    {path:'AddClinic',component:AddClinicsComponent},
    {path:'List',component:ClinicListComponent},
    
    
  ]

}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClinicsRoutingModule { }
