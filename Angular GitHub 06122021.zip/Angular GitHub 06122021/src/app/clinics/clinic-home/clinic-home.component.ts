import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clinic-home',
  templateUrl: './clinic-home.component.html',
  styleUrls: ['./clinic-home.component.scss']
})
export class ClinicHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
