import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ClinicHomeComponent } from './clinic-home.component';

describe('ClinicHomeComponent', () => {
  let component: ClinicHomeComponent;
  let fixture: ComponentFixture<ClinicHomeComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ClinicHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
